# 🚀 CodeBuddy 终极合辑：从零到企业级使用手册

想把 AI 真正融入终端工作流？这一篇只回答“怎么用”：从安装、建模、记忆、权限，到多代理、插件、竞品组合，一条路径走完。建议边看边在自己的项目执行，5 分钟一个动作，整篇跟下来就能拥有可落地的终端 AI 搭档。

## 1. 先跑起来：五步完成基础使用
1. **环境体检**：在终端跑 `node --version`、`npm --version`，若低于 18 建议升级；Windows 用户记得打开 PowerShell 执行策略。
2. **安装指令**：`npm install -g @tencent-ai/codebuddy-code`。安装完输入 `codebuddy --version` 验证。若要使用官方脚本，macOS/Linux 可运行 `curl -fsSL https://copilot.tencent.com/cli/install.sh | bash`，Windows 用 `irm ... install.ps1 | iex`。
3. **启动登录**：切到项目根目录运行 `codebuddy`（或别名 `cbc`），在登录菜单选择中国站、海外站、Enterprise Domain、iOA 等入口，按上下键回车即可。登录完成后终端会保存凭证，下次直接进入。
4. **必跑 `/init`**：第一次进入项目一定先输入 `/init`，让 CodeBuddy 扫描目录、构建知识图谱。仓库越大收益越明显，后续所有回答都基于这份知识缓存。
5. **安全执行**：任何任务先输入 `/plan` 生成计划，再依次确认。需要 Web 面板时输入 `/web` 打开浏览器，适合分享会话给团队或查看历史。

> 如果家里有多台机器，建议把 `~/.codebuddy` 拷贝到云盘或 Git 私仓（注意排除密钥文件），这样在新电脑上复制即可继承模型与记忆配置。

## 2. 模型配置：用 `models.json` 做“模型中控”
- **用户级 `~/.codebuddy/models.json`**：放所有项目都能使用的模型、代理、默认参数。
- **项目级 `<workspace>/.codebuddy/models.json`**：针对单个仓库覆盖温度、token、端点、可用模型列表。
- 常用写法：
```json
{
  "models": [
    {
      "id": "gpt-4o",
      "name": "GPT-4o (公司代理)",
      "vendor": "OpenAI",
      "url": "https://proxy.example.com/v1/chat/completions",
      "apiKey": "${PROXY_KEY}",
      "supportsToolCall": true
    }
  ],
  "availableModels": ["gpt-4o", "gpt-4o-mini"]
}
```
- `availableModels` 决定下拉框显示谁；`${ENV_NAME}` 引用环境变量即可安全切换。
- 别忘了 `supportsToolCall`、`supportsImages`、`maxInputTokens`、`maxOutputTokens` 等字段，根据模型能力填写，避免在执行时被拒。
- 保存文件后 1 秒内热更新，如终端没提示可输入 `/reload` 手动刷新。

> 建议建立一个“模型攻略”文档，记录不同模型擅长的任务、成本，填好 `availableModels` 后团队成员就不会乱选。

## 3. Memory & Rules：让 AI 记住“我们的做事方式”
- `~/.codebuddy/CODEBUDDY.md`：写个人常用命令、编辑器喜好、常驻项目列表。
- `.codebuddy/CODEBUDDY.md`：写项目背景、模块结构、构建/测试命令、重要目录。
- `.codebuddy/rules/*.md`：按角色拆分规范，例如 `frontend.md`、`backend.md`、`security.md`，方便 Sub-Agent 定向加载。
- `CODEBUDDY.local.md`：只在本机生效，适合放临时说明、尚未公开的需求。
- 文件中使用 `@import docs/xxx.md`、`@import README.md` 把长文档一次性引用，保持单一维护点。
- 运行 `/memory` 查看哪些知识已加载；想清空可用 `/memory clear`，再 `/init` 重新同步。
- 设置 `CODEBUDDY_TYPED_MEMORY_ENABLED=true` 让 CLI 自动记录常见命令、最近任务摘要，配合 `CODEBUDDY_AUTO_MEMORY_MAX_ITEMS` 控制数量。

> 建议把团队规范写成“必须/可选/禁止”格式，AI 回复时会直接引用这些条目，减少来回确认。

## 4. 环境变量：一次配置，全员生效
在 `~/.codebuddy/settings.json` 中写：
```json
{
  "env": {
    "CODEBUDDY_DEFAULT_PERMISSION_MODE": "plan",
    "CODEBUDDY_ALLOWLIST_COMMANDS": "git status,git diff",
    "CODEBUDDY_DENYLIST_COMMANDS": "rm -rf,shutdown",
    "CODEBUDDY_MODEL": "gpt-4o",
    "CODEBUDDY_TYPED_MEMORY_ENABLED": "true",
    "CODEBUDDY_PLUGIN_DIRS": "/Users/lin/.codebuddy/plugins",
    "CODEBUDDY_DISABLE_CRON": "false"
  }
}
```
Shell 中也可临时 `export CODEBUDDY_DEFAULT_MODEL=gpt-4o`。CI、容器环境则把这些变量写进 Secrets。

常见分类：
- 模型：`CODEBUDDY_MODEL`、`SMALL_FAST_MODEL`、`BIG_SLOW_MODEL`、`CODEBUDDY_MODEL_MAP`
- 权限：`CODEBUDDY_DEFAULT_PERMISSION_MODE`、`CODEBUDDY_ALLOWLIST_COMMANDS`、`CODEBUDDY_DENYLIST_COMMANDS`
- 记忆/日志：`CODEBUDDY_TYPED_MEMORY_ENABLED`、`CODEBUDDY_DISABLE_AUTO_MEMORY`、`CODEBUDDY_LOG_LEVEL`
- 插件/调度：`CODEBUDDY_PLUGIN_DIRS`、`CODEBUDDY_DISABLE_CRON`、`CODEBUDDY_DAEMON_STARTUP`

> 维护多人环境时，可在 Git 仓库里放一个 `settings.template.json`，每位同事复制后填入自己的密钥字段即可。

## 5. 多 Agent：把 AI 分工明确
- `/agents` 创建分身，分别设置角色提示、允许访问的目录、可用工具。
  - 例：`日志巡检员` 只读 `logs/`，工具限定 `rg`、`python`。
  - 例：`安全顾问` 绑定 `rules/security.md`，禁止写生产目录。
- `/team` 把分身编成虚拟 Scrum（需求→开发→测试→复盘），终端里即可看到多角色协作。

使用建议：
- 把代理配置成 YAML/JSON 模板后备份到 Git，换机器直接复制。
- 对需要审批的操作，可设专门的“审计代理”负责 `/plan` 复核。
- 区分“会话级代理”和“守护代理”：前者解决即时任务，后者配合 Daemon/Scheduled Tasks 自动运行。

## 6. 插件、MCP、Daemon、Scheduled Tasks
- 插件市场与 MCP 让 CodeBuddy 调用浏览器、数据库、外部 API，装好后用 `/plugins` 管理。
- `codebuddy daemon start` 让 CLI 常驻后台；
- `/tasks` 或 `config scheduledTasks` 设定定时任务，例如每天 9 点自动跑 `/plan`、`/test`，输出巡检报告。
- 需求：巡检日志、每日提醒、夜间编译等全部交给守护流程。

典型组合：
1. “晨会机器人”：Daemon + Scheduled Task → 早上 8 点运行 `/plan` “检查最新 PR” → 结果推送钉钉/企业微信。
2. “日志哨兵”：插件连接 ELK/Kibana → 每小时读取告警 → 提示下一步命令。
3. “网页调试官”：安装 Chrome DevTools MCP → 让 CodeBuddy 直接打开页面、执行脚本、截图。

## 7. 安全 & 权限：上线前必须完成的动作
1. 保持权限模式在 `plan`，所有写操作先呈现执行计划。
2. 开启 Bash Sandboxing，把 CLI 锁在项目目录，限制网络及命令集合。
3. 企业环境下启用企业域名登录或 SSO，保证身份可控。
4. 设置 `CODEBUDDY_ALLOWLIST_COMMANDS`、`CODEBUDDY_DENYLIST_COMMANDS`、`CODEBUDDY_DANGEROUS_COMMANDS`。
5. 打开 `CODEBUDDY_LOG_LEVEL=debug` 配合 Cost Management，记录命令与费用。

此外：
- 对需要联网的任务，启用代理白名单/黑名单，防止访问未知域。
- 使用 Git 钩子或 CI，把 CodeBuddy 生成的 patch 自动跑测试，确保执行结果符合期待。
- 关键操作（部署、删库）务必借助 `/plan` + 负责人复核，必要时结合命令审批机器人。

## 8. 竞品混搭：不同场景用不同 CLI
| 工具 | 使用场景 | 特点 |
| --- | --- | --- |
| OpenCode | 做实验、测试新模型或 LSP，使用 TUI Mission Control、`opencode share` 链接 | 完全开源，内置 75+ 模型，可接 Chrome DevTools MCP |
| Claude Code | 需要 Auto Mode、语音 `/voice`、Cowork GUI 时使用 | 体验优秀，但要关注权限和第三方收费策略 |
| Gemini CLI | 需要 Google Search grounding、1M token、Zed/Antigravity 联动时 | 开源、原生 Google 生态，但模型上下线要跟官方节奏 |
| Kimi CLI | 大规模生成网站/文档、尝试 Agent Swarm | 国产 1T 模型，最多 100 子代理并行，需申请配额 |

建议：CodeBuddy 承担主力开发与治理，OpenCode 当实验室，Gemini CLI 负责查实时资料，Kimi CLI 负责批量生成。

## 9. 模型与套餐速览：CodeBuddy 及常见 CLI 怎么收费？

| 工具 | 默认可用模型 | 是否可自带模型 | 费用与套餐提示 |
| --- | --- | --- | --- |
| CodeBuddy（中国站） | 腾讯云混元系列、行业模型、Claude 4.x（按账号权限开放） | 是，通过 `models.json` 接入 OpenAI、OpenRouter、DeepSeek、自建代理 | CLI 免费。模型费用跟随腾讯云计费（预付/按量皆可）。企业可申请专属套餐、私有化或定制模型池 |
| CodeBuddy（海外站） | Tencent Cloud Global 模型、Claude 4.x、兼容 OpenAI API | 是 | CLI 免费。需要绑定海外腾讯云或外部 API。支持企业 License、席位制、托管部署 |
| OpenCode | 官方预置 75+ 模型（OpenAI、Anthropic、Gemini、Bedrock、Groq 等） | 是，完全 BYO Provider | 开源免费。仅支付所调用模型的 API 费用，可通过 Vertex/Bedrock 等统一结算 |
| Claude Code | Anthropic Opus/Sonnet/Haiku（Auto Mode、/voice 走自家模型） | 否 | 无 CLI 费用，但需要 Anthropic 订阅或 API 额度。使用第三方代理（OpenClaw 等）会产生额外通道费 |
| Gemini CLI | Gemini 2.5/3.x（Flash/Pro）+ 1M Token 上下文 + Google Search Grounding | 否（仅 Gemini API） | CLI 开源免费。需绑定 Google Cloud 账号，按 Gemini API 计费；免费层有配额，但模型下线需同步升级 |
| Kimi CLI / Kimi Code | Moonshot Kimi K2.5（1T 参数），支持 Agent Swarm、并行 100 子代理 | 否（走 Moonshot API） | CLI 开源。使用需购买 Moonshot Coding 套餐（$0.60/百万输入 Token，$3/百万输出 Token）或申请企业额度 |

补充说明：
- CodeBuddy 的 CLI 不额外收费，主要开支来自所绑定的模型或企业套餐。腾讯云账号可按量、包年包月或企业定制三种模式；私有化部署需联系官方商务。
- 如果团队已有 OpenAI/Groq/DeepSeek 等密钥，直接在 `models.json` 引用即可；记得在 `settings.json` 中集中管理 `apiKey`、`url`，便于统一轮换。
- OpenCode、Gemini CLI、Kimi CLI 都是“工具免费 + 模型计费”的逻辑。评估时要把模型费用纳入预算，并关注不同供应商的配额策略。

## 10. 使用 Checklist
1. `codebuddy` 安装、登录、执行 `/init`
2. 整理 `models.json`（用户级 + 项目级）并热更新
3. 写好 `CODEBUDDY.md`、`.codebuddy/rules/`、`CODEBUDDY.local.md`
4. 下发环境变量模板或 `settings.json`
5. 配置 Sub-Agent、Agent Team，并尝试 `/plan`
6. 启用 Bash Sandboxing、权限白/黑名单、IAM
7. 根据项目场景选择是否联动 OpenCode、Claude Code、Gemini CLI、Kimi CLI

照着做，CodeBuddy 会从“聊天机器人”升级为“终端执行搭档”，既懂你的项目，又守你的规矩，还能自动运行日常任务。
